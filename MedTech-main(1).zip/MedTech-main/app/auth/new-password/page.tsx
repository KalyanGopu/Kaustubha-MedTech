import { NewPasswordForm } from "@/components/auth/newpassord";

export default function NewPasswordPage(){
    return(
        <NewPasswordForm/>
    )
}