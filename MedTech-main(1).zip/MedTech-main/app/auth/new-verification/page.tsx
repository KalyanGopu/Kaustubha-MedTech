import NewVerificationForm from "@/components/auth/new-verification-form"

const NewVerificationPage = () =>{
    return (
        <div>
            <NewVerificationForm/>
        </div>
    )
}

export default NewVerificationPage