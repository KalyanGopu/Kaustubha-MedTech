import { Loginnew } from "@/components/auth/login";
import { LoginForm } from "@/components/auth/login-form";


export default function Login(){
    return(
        <div>
            <LoginForm/>
        </div>
    )
}