import { OtpVerification } from "@/components/auth/otp";

const Otp= ()=>{
    return(
        <div>
            <OtpVerification/>
        </div>
    )
}

export default Otp;