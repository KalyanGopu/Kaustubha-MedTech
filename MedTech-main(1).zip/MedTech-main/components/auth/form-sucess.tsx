
export default function FormSucess({message}:{message :string | undefined}){
    return(
        <div>
            {message}
        </div>
    )
}